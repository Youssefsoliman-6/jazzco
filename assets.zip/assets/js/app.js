(function () {
    const qs = (s, parent = document) => parent.querySelector(s);
    const qsa = (s, parent = document) => [...parent.querySelectorAll(s)];

    window.JazzCO = window.JazzCO || {};
    window.JazzCO.toast = function (message, type = 'success') {
        const stack = qs('#toastStack');
        if (!stack) return alert(message);
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = message;
        stack.appendChild(toast);
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(20px)';
            setTimeout(() => toast.remove(), 240);
        }, 3300);
    };

    function applyTheme(theme) {
        const next = theme === 'light' ? 'light' : 'dark';
        if (next === 'light') document.documentElement.setAttribute('data-theme', 'light');
        else document.documentElement.removeAttribute('data-theme');
        try { localStorage.setItem('jazzco_theme', next); } catch (e) {}
        qsa('[data-theme-toggle]').forEach(btn => {
            btn.textContent = next === 'light' ? 'Dark mode' : 'Light mode';
            btn.setAttribute('aria-label', `Switch to ${next === 'light' ? 'dark' : 'light'} mode`);
        });
    }

    const savedTheme = (() => {
        try { return localStorage.getItem('jazzco_theme') || 'dark'; } catch (e) { return 'dark'; }
    })();
    applyTheme(savedTheme);

    window.addEventListener('load', () => {
        setTimeout(() => qs('#loadingScreen')?.classList.add('hide'), 350);
        (window.__JAZZ_FLASHES__ || []).forEach(f => window.JazzCO.toast(f.message, f.type));
    });

    qs('#hamburger')?.addEventListener('click', () => qs('#mainNav')?.classList.toggle('show'));

    qsa('[data-theme-toggle]').forEach(btn => {
        btn.addEventListener('click', () => {
            const current = document.documentElement.getAttribute('data-theme') === 'light' ? 'light' : 'dark';
            applyTheme(current === 'light' ? 'dark' : 'light');
        });
    });

    // Live AJAX search component: add <input data-live-search> and <div data-search-results>.
    const searchInput = qs('[data-live-search]');
    const searchResults = qs('[data-search-results]');
    let searchTimer;
    if (searchInput && searchResults) {
        searchInput.addEventListener('input', () => {
            clearTimeout(searchTimer);
            const q = searchInput.value.trim();
            if (q.length < 2) {
                searchResults.classList.remove('show');
                searchResults.innerHTML = '';
                return;
            }
            searchTimer = setTimeout(async () => {
                try {
                    const res = await fetch(`search.php?q=${encodeURIComponent(q)}`);
                    const data = await res.json();
                    const groups = [];
                    if (data.songs?.length) groups.push(...data.songs.map(x => searchItem(x, 'Song')));
                    if (data.artists?.length) groups.push(...data.artists.map(x => searchItem(x, 'Artist')));
                    if (data.albums?.length) groups.push(...data.albums.map(x => searchItem(x, 'Album')));
                    if (data.playlists?.length) groups.push(...data.playlists.map(x => searchItem(x, 'Playlist')));
                    searchResults.innerHTML = groups.join('') || '<div class="helper">No results found.</div>';
                    searchResults.classList.add('show');
                } catch (err) {
                    searchResults.innerHTML = '<div class="helper">Search failed.</div>';
                    searchResults.classList.add('show');
                }
            }, 220);
        });
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.search-shell')) searchResults.classList.remove('show');
        });
    }

    function searchItem(item, type) {
        const img = item.image || item.cover || 'assets/images/covers/default-cover.svg';
        const title = escapeHtml(item.title || item.name);
        const sub = escapeHtml(item.subtitle || type);
        const songAction = type === 'Song' ? `data-play-song="${item.id}"` : '';
        const url = item.url ? escapeAttr(item.url) : '';
        const tag = url ? 'a' : 'div';
        const href = url ? `href="${url}"` : '';
        return `<${tag} class="search-item" ${href} ${songAction}>
            <img src="${escapeAttr(img)}" alt="">
            <div><strong>${title}</strong><div class="helper">${sub}</div></div>
            <span class="badge">${type}</span>
        </${tag}>`;
    }

    function escapeHtml(str) {
        return String(str ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c]));
    }

    function escapeAttr(str) {
        return escapeHtml(str).replace(/`/g, '&#096;');
    }
})();
