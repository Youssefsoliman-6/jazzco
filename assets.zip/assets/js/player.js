class JazzPlayer {
    constructor() {
        this.audio = document.getElementById('audioEngine');
        this.base = (window.JAZZCO_BASE_URL || '').replace(/\/?$/, '/');
        this.queue = [];
        this.librarySongs = [];
        this.knownSongs = new Map();
        this.index = 0;
        this.shuffle = false;
        this.repeat = false;
        this.page = 0;
        this.loading = false;
        this.hasMore = true;
        this.savedState = this.readState();
        this.pendingSeek = null;
        this.pendingAutoplay = false;
        this.playlistSongId = null;
        this.storageKey = 'jazzco_player_state_v2';
        this.init();
    }

    async init() {
        if (!this.audio) return;
        this.bindUI();
        this.restoreSettings();
        await this.restoreSavedQueue();
        await this.loadSongs();

        if (this.queue.length) {
            const safeIndex = Math.min(Math.max(0, Number(this.savedState.index || 0)), this.queue.length - 1);
            this.pendingSeek = Number(this.savedState.currentTime || 0);
            this.pendingAutoplay = !!this.savedState.playing;
            this.loadTrack(safeIndex, false);
        }

        this.saveTimer = setInterval(() => this.saveState(), 1500);
        window.addEventListener('beforeunload', () => this.saveState());
    }

    qs(sel, parent = document) { return parent.querySelector(sel); }
    qsa(sel, parent = document) { return [...parent.querySelectorAll(sel)]; }
    url(path) { return `${this.base}${String(path).replace(/^\//, '')}`; }

    bindUI() {
        const bindClick = (selector, handler) => this.qs(selector)?.addEventListener('click', handler);

        bindClick('#playBtn', () => this.toggle());
        bindClick('#miniPlayBtn', () => this.toggle());
        bindClick('#nextBtn', () => this.next());
        bindClick('#miniNextBtn', () => this.next());
        bindClick('#prevBtn', () => this.prev());
        bindClick('#miniPrevBtn', () => this.prev());
        bindClick('#fullBtn', () => document.body.classList.toggle('fullscreen-mode'));
        bindClick('#favoriteBtn', () => this.toggleFavorite());
        bindClick('#miniQueueBtn', () => this.openQueueDrawer());
        bindClick('#closeQueueDrawer', () => this.closeDrawers());
        bindClick('#modalBackdrop', () => this.closeDrawers());
        bindClick('#clearQueueBtn', () => this.clearQueue());
        bindClick('#closePlaylistModal', () => this.closeDrawers());

        const toggleShuffle = () => { this.shuffle = !this.shuffle; this.syncToggleButtons(); this.saveState(); };
        const toggleRepeat = () => { this.repeat = !this.repeat; this.syncToggleButtons(); this.saveState(); };
        bindClick('#shuffleBtn', toggleShuffle);
        bindClick('#miniShuffleBtn', toggleShuffle);
        bindClick('#repeatBtn', toggleRepeat);
        bindClick('#miniRepeatBtn', toggleRepeat);

        ['#progress', '#miniProgress'].forEach(selector => {
            this.qs(selector)?.addEventListener('input', e => {
                this.audio.currentTime = Number(e.target.value);
                this.updateProgress();
                this.saveState();
            });
        });

        const syncVolume = value => {
            this.audio.volume = Number(value);
            ['#volume', '#miniVolume'].forEach(selector => {
                const slider = this.qs(selector);
                if (slider) slider.value = value;
            });
            this.saveState();
        };
        ['#volume', '#miniVolume'].forEach(selector => {
            this.qs(selector)?.addEventListener('input', e => syncVolume(e.target.value));
        });

        this.audio.addEventListener('timeupdate', () => this.updateProgress());
        this.audio.addEventListener('loadedmetadata', () => this.onMetadataReady());
        this.audio.addEventListener('play', () => { this.setPlaying(true); this.saveState(); });
        this.audio.addEventListener('pause', () => { this.setPlaying(false); this.saveState(); });
        this.audio.addEventListener('ended', () => this.repeat ? this.play() : this.next());

        document.addEventListener('keydown', e => this.keyboard(e));
        document.addEventListener('click', e => this.handleDocumentClick(e));
        window.addEventListener('scroll', () => {
            if (!this.qs('#songGrid')) return;
            if (!this.hasMore || this.loading) return;
            if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 600) this.loadSongs();
        });

        this.qs('#quickPlaylistForm')?.addEventListener('submit', e => this.createPlaylistAndAdd(e));
    }

    handleDocumentClick(e) {
        const playPlaylist = e.target.closest('[data-play-playlist]');
        if (playPlaylist) {
            e.preventDefault();
            this.addManyToQueue(this.idsFromDataset(playPlaylist.dataset.playPlaylist), true, true);
            return;
        }

        const queuePlaylist = e.target.closest('[data-add-playlist-queue]');
        if (queuePlaylist) {
            e.preventDefault();
            this.addManyToQueue(this.idsFromDataset(queuePlaylist.dataset.addPlaylistQueue), false, false);
            return;
        }

        const addToPlaylist = e.target.closest('[data-add-to-playlist]');
        if (addToPlaylist) {
            e.preventDefault();
            this.addSongToPlaylist(Number(addToPlaylist.dataset.addToPlaylist));
            return;
        }

        const playlistBtn = e.target.closest('[data-playlist-song]');
        if (playlistBtn) {
            e.preventDefault();
            this.openPlaylistModal(Number(playlistBtn.dataset.playlistSong));
            return;
        }

        const removeQueue = e.target.closest('[data-remove-queue]');
        if (removeQueue) {
            e.preventDefault();
            this.removeFromQueue(Number(removeQueue.dataset.removeQueue));
            return;
        }

        const addBtn = e.target.closest('[data-add-queue]');
        if (addBtn) {
            e.preventDefault();
            this.addToQueue(Number(addBtn.dataset.addQueue), false);
            return;
        }

        const playBtn = e.target.closest('[data-play-song]');
        if (playBtn) {
            e.preventDefault();
            this.playById(Number(playBtn.dataset.playSong));
            return;
        }

        const queueItem = e.target.closest('[data-play-index]');
        if (queueItem && !e.target.closest('button,a,form,input')) {
            this.loadTrack(Number(queueItem.dataset.playIndex), true);
        }
    }

    idsFromDataset(value) {
        return String(value || '').split(',').map(x => Number(x.trim())).filter(Boolean);
    }

    restoreSettings() {
        const savedVolume = Number(this.savedState.volume ?? 0.75);
        this.audio.volume = Number.isFinite(savedVolume) ? Math.max(0, Math.min(1, savedVolume)) : 0.75;
        ['#volume', '#miniVolume'].forEach(selector => {
            const slider = this.qs(selector);
            if (slider) slider.value = this.audio.volume;
        });
        this.shuffle = !!this.savedState.shuffle;
        this.repeat = !!this.savedState.repeat;
        this.syncToggleButtons();
    }

    readState() {
        try {
            return JSON.parse(localStorage.getItem('jazzco_player_state_v2') || '{}') || {};
        } catch (e) {
            return {};
        }
    }

    saveState() {
        if (!this.audio) return;
        try {
            const state = {
                ids: this.queue.map(song => song.id),
                index: this.index,
                currentTime: this.audio.currentTime || 0,
                volume: this.audio.volume,
                shuffle: this.shuffle,
                repeat: this.repeat,
                playing: !this.audio.paused && !this.audio.ended,
                updatedAt: Date.now()
            };
            localStorage.setItem(this.storageKey, JSON.stringify(state));
        } catch (e) {}
    }

    async restoreSavedQueue() {
        const ids = Array.isArray(this.savedState.ids) ? this.savedState.ids.map(Number).filter(Boolean) : [];
        if (!ids.length) return;
        try {
            const res = await fetch(this.url(`api_songs.php?ids=${encodeURIComponent(ids.join(','))}`));
            const data = await res.json();
            this.queue = (data.songs || []);
            this.queue.forEach(song => this.knownSongs.set(song.id, song));
            this.renderQueue();
        } catch (err) {
            this.queue = [];
        }
    }

    async loadSongs() {
        if (this.loading || !this.hasMore) return;
        this.loading = true;
        try {
            const res = await fetch(this.url(`api_songs.php?offset=${this.page * 20}&limit=20`));
            const data = await res.json();
            this.hasMore = !!data.has_more;
            const songs = data.songs || [];
            songs.forEach(song => {
                this.knownSongs.set(song.id, song);
                if (!this.librarySongs.some(s => s.id === song.id)) this.librarySongs.push(song);
            });
            this.page += 1;
            this.renderLibrary(songs);

            if (!this.queue.length && songs.length) {
                this.queue = [...songs];
                this.index = 0;
                this.loadTrack(0, false);
            }
            this.renderQueue();
        } catch (err) {
            window.JazzCO?.toast('Could not load songs.', 'error');
        } finally {
            this.loading = false;
        }
    }

    renderLibrary(songs) {
        const grid = this.qs('#songGrid');
        if (!grid) return;
        if (!songs.length && !this.librarySongs.length) {
            grid.innerHTML = '<div class="card helper">No songs yet. Upload tracks from the admin dashboard.</div>';
            return;
        }
        songs.forEach(song => {
            const card = document.createElement('article');
            card.className = 'card';
            card.innerHTML = `<img class="song-cover" src="${this.escAttr(song.cover)}" alt="${this.esc(song.title)} cover">
                <div class="card-title">${this.esc(song.title)}</div>
                <div class="card-sub">${this.esc(song.artist)} • ${this.format(song.duration)}</div>
                <div class="row-actions">
                    <button class="btn small primary" data-play-song="${song.id}">Play</button>
                    <button class="btn small" data-add-queue="${song.id}">Queue</button>
                    <button class="btn small" data-playlist-song="${song.id}">Playlist</button>
                </div>`;
            grid.appendChild(card);
        });
    }

    renderQueue() {
        const html = this.queue.length ? this.queue.map((song, i) => this.queueItemHtml(song, i)).join('') : '<div class="empty-state small">Queue is empty. Add songs from the library.</div>';
        const list = this.qs('#queueList');
        if (list) list.innerHTML = html;
        const global = this.qs('#globalQueueList');
        if (global) global.innerHTML = html;
    }

    queueItemHtml(song, i) {
        return `<div class="queue-item ${i === this.index ? 'active' : ''}" data-play-index="${i}">
            <img src="${this.escAttr(song.cover)}" alt="">
            <div>
                <h4>${this.esc(song.title)}</h4>
                <p>${this.esc(song.artist)} • ${this.format(song.duration)}</p>
                <div class="queue-actions">
                    <button class="micro-btn" data-play-song="${song.id}">Play</button>
                    <button class="micro-btn" data-playlist-song="${song.id}">Playlist</button>
                    <button class="micro-btn danger" data-remove-queue="${i}">Remove</button>
                </div>
            </div>
        </div>`;
    }

    async fetchSong(id) {
        if (this.knownSongs.has(id)) return this.knownSongs.get(id);
        const res = await fetch(this.url(`api_song.php?id=${encodeURIComponent(id)}`));
        const data = await res.json();
        if (!data.ok || !data.song) throw new Error(data.message || 'Song not found');
        this.knownSongs.set(data.song.id, data.song);
        return data.song;
    }

    async addToQueue(id, playNow = false) {
        if (!id) return;
        try {
            const song = await this.fetchSong(id);
            let idx = this.queue.findIndex(s => s.id === song.id);
            if (idx < 0) {
                this.queue.push(song);
                idx = this.queue.length - 1;
                window.JazzCO?.toast('Added to queue.');
            } else if (!playNow) {
                window.JazzCO?.toast('This song is already in your queue.');
            }
            this.renderQueue();
            if (playNow) this.loadTrack(idx, true);
            this.saveState();
        } catch (err) {
            window.JazzCO?.toast('Could not add song to queue.', 'error');
        }
    }

    async addManyToQueue(ids, playNow = false, replace = false) {
        if (!ids.length) return;
        try {
            const res = await fetch(this.url(`api_songs.php?ids=${encodeURIComponent(ids.join(','))}`));
            const data = await res.json();
            const songs = data.songs || [];
            if (!songs.length) return;
            songs.forEach(song => this.knownSongs.set(song.id, song));
            if (replace) {
                this.queue = [...songs];
                this.index = 0;
                this.renderQueue();
                this.loadTrack(0, playNow);
                window.JazzCO?.toast('Playlist loaded into player.');
            } else {
                let added = 0;
                songs.forEach(song => {
                    if (!this.queue.some(s => s.id === song.id)) {
                        this.queue.push(song);
                        added++;
                    }
                });
                this.renderQueue();
                window.JazzCO?.toast(added ? `${added} song(s) added to queue.` : 'Songs are already in your queue.');
            }
            this.saveState();
        } catch (err) {
            window.JazzCO?.toast('Could not load playlist songs.', 'error');
        }
    }

    playById(id) {
        const idx = this.queue.findIndex(s => s.id === id);
        if (idx >= 0) this.loadTrack(idx, true);
        else this.addToQueue(id, true);
    }

    loadTrack(i, autoplay = true) {
        if (!this.queue.length) return;
        this.index = (i + this.queue.length) % this.queue.length;
        const s = this.queue[this.index];
        this.audio.src = s.src;

        const setText = (selector, value) => { const el = this.qs(selector); if (el) el.textContent = value; };
        const setImage = (selector, value) => { const el = this.qs(selector); if (el) el.src = value; };
        setImage('#nowCover', s.cover);
        setText('#nowTitle', s.title);
        setText('#nowArtist', `${s.artist} • ${s.album}`);
        setImage('#miniCover', s.cover);
        setText('#miniTitle', s.title);
        setText('#miniArtist', s.artist);
        setText('#duration', this.format(s.duration));
        setText('#miniDuration', this.format(s.duration));
        this.renderQueue();
        this.trackRecent(s.id);
        this.updateProgress();
        this.saveState();

        if (autoplay) this.play();
        if ('mediaSession' in navigator) {
            navigator.mediaSession.metadata = new MediaMetadata({
                title: s.title,
                artist: s.artist,
                album: s.album,
                artwork: [{ src: s.cover, sizes: '512x512', type: 'image/png' }]
            });
            navigator.mediaSession.setActionHandler?.('play', () => this.play());
            navigator.mediaSession.setActionHandler?.('pause', () => this.pause());
            navigator.mediaSession.setActionHandler?.('nexttrack', () => this.next());
            navigator.mediaSession.setActionHandler?.('previoustrack', () => this.prev());
        }
    }

    onMetadataReady() {
        if (this.pendingSeek !== null && Number.isFinite(this.pendingSeek) && this.pendingSeek > 0) {
            const duration = this.audio.duration || 0;
            this.audio.currentTime = duration ? Math.min(this.pendingSeek, Math.max(0, duration - 1)) : this.pendingSeek;
            this.pendingSeek = null;
        }
        this.updateDuration();
        if (this.pendingAutoplay) {
            this.pendingAutoplay = false;
            this.play(true);
        }
    }

    removeFromQueue(i) {
        if (i < 0 || i >= this.queue.length) return;
        const wasCurrent = i === this.index;
        this.queue.splice(i, 1);
        if (!this.queue.length) {
            this.audio.pause();
            this.audio.removeAttribute('src');
            this.audio.load();
            this.index = 0;
            this.updateNowEmpty();
        } else {
            if (i < this.index) this.index--;
            if (wasCurrent) this.loadTrack(Math.min(i, this.queue.length - 1), true);
        }
        this.renderQueue();
        this.saveState();
    }

    clearQueue() {
        if (!this.queue.length) return;
        if (!confirm('Clear your current queue?')) return;
        this.queue = [];
        this.index = 0;
        this.audio.pause();
        this.audio.removeAttribute('src');
        this.audio.load();
        this.updateNowEmpty();
        this.renderQueue();
        this.saveState();
        window.JazzCO?.toast('Queue cleared.');
    }

    updateNowEmpty() {
        const cover = this.url('assets/images/covers/default-cover.svg');
        [['#nowCover', cover], ['#miniCover', cover]].forEach(([selector, value]) => { const el = this.qs(selector); if (el) el.src = value; });
        [['#nowTitle', 'Nothing playing'], ['#nowArtist', 'Add songs to your queue'], ['#miniTitle', 'Nothing playing'], ['#miniArtist', 'Choose a track']].forEach(([selector, value]) => { const el = this.qs(selector); if (el) el.textContent = value; });
        this.setPlaying(false);
        this.updateProgress();
    }

    openQueueDrawer() {
        this.qs('#queueDrawer')?.classList.add('show');
        this.qs('#modalBackdrop')?.classList.add('show');
        this.qs('#queueDrawer')?.setAttribute('aria-hidden', 'false');
    }

    closeDrawers() {
        this.qs('#queueDrawer')?.classList.remove('show');
        this.qs('#playlistModal')?.classList.remove('show');
        this.qs('#modalBackdrop')?.classList.remove('show');
        this.qs('#queueDrawer')?.setAttribute('aria-hidden', 'true');
        this.qs('#playlistModal')?.setAttribute('aria-hidden', 'true');
    }

    async openPlaylistModal(songId) {
        if (!songId) return;
        if (!window.JAZZCO_LOGGED_IN) {
            this.playlistSongId = songId;
            this.qs('#playlistModal')?.classList.add('show');
            this.qs('#modalBackdrop')?.classList.add('show');
            return;
        }
        this.playlistSongId = songId;
        const song = await this.fetchSong(songId).catch(() => null);
        const label = this.qs('#playlistModalSong');
        if (label && song) label.textContent = `Choose a playlist for “${song.title}”.`;
        this.qs('#playlistModal')?.classList.add('show');
        this.qs('#modalBackdrop')?.classList.add('show');
        this.qs('#playlistModal')?.setAttribute('aria-hidden', 'false');
        this.loadPlaylistChoices();
    }

    async loadPlaylistChoices() {
        const box = this.qs('#playlistChooser');
        if (!box) return;
        box.innerHTML = '<p class="helper">Loading playlists...</p>';
        try {
            const res = await fetch(this.url('playlist_api.php?action=list'));
            const data = await res.json();
            const playlists = data.playlists || [];
            box.innerHTML = playlists.length ? playlists.map(p => `<button class="playlist-choice" type="button" data-add-to-playlist="${p.id}">
                <img src="${this.escAttr(p.cover || this.url('assets/images/covers/default-cover.svg'))}" alt="">
                <span><strong>${this.esc(p.name)}</strong><small>${p.is_public == 1 ? 'Public' : 'Private'} • ${p.song_count || 0} songs</small></span>
            </button>`).join('') : '<p class="helper">No playlists yet. Create one below.</p>';
        } catch (err) {
            box.innerHTML = '<p class="helper">Could not load playlists.</p>';
        }
    }

    async addSongToPlaylist(playlistId) {
        if (!playlistId || !this.playlistSongId) return;
        try {
            const res = await fetch(this.url('playlist_api.php'), {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'add_song', playlist_id: playlistId, song_id: this.playlistSongId })
            });
            const data = await res.json();
            if (!data.ok) throw new Error(data.message || 'Failed');
            window.JazzCO?.toast('Song added to playlist.');
            this.closeDrawers();
        } catch (err) {
            window.JazzCO?.toast(err.message || 'Could not add song to playlist.', 'error');
        }
    }

    async createPlaylistAndAdd(e) {
        e.preventDefault();
        if (!this.playlistSongId) return;
        const form = e.currentTarget;
        const fd = new FormData(form);
        const body = {
            action: 'create',
            name: fd.get('name'),
            description: fd.get('description'),
            is_public: fd.get('is_public') ? 1 : 0
        };
        try {
            const res = await fetch(this.url('playlist_api.php'), {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            });
            const data = await res.json();
            if (!data.ok) throw new Error(data.message || 'Could not create playlist');
            await this.addSongToPlaylist(data.id);
            form.reset();
        } catch (err) {
            window.JazzCO?.toast(err.message || 'Playlist creation failed.', 'error');
        }
    }

    async toggleFavorite() {
        const s = this.queue[this.index];
        if (!s) return;
        try {
            const res = await fetch(this.url('favorite_api.php'), { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({song_id: s.id}) });
            const data = await res.json();
            if (!data.ok) throw new Error(data.message || 'Failed');
            window.JazzCO?.toast(data.favorited ? 'Added to favorites.' : 'Removed from favorites.');
        } catch (e) {
            window.JazzCO?.toast('Login required to favorite songs.', 'error');
        }
    }

    async trackRecent(songId) {
        fetch(this.url('recent_api.php'), { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({song_id: songId}) }).catch(() => {});
    }

    toggle() { this.audio.paused ? this.play() : this.pause(); }
    play(silent = false) {
        if (!this.audio.src && this.queue.length) this.loadTrack(this.index, false);
        this.audio.play().then(() => this.setPlaying(true)).catch(() => {
            this.setPlaying(false);
            if (!silent) window.JazzCO?.toast('Browser blocked playback. Click play again.', 'error');
        });
    }
    pause() { this.audio.pause(); this.setPlaying(false); }
    setPlaying(on) { ['#playBtn','#miniPlayBtn'].forEach(id => { const b = this.qs(id); if (b) b.textContent = on ? '❚❚' : '▶'; }); }
    syncToggleButtons() {
        ['#shuffleBtn', '#miniShuffleBtn'].forEach(id => this.qs(id)?.classList.toggle('active', this.shuffle));
        ['#repeatBtn', '#miniRepeatBtn'].forEach(id => this.qs(id)?.classList.toggle('active', this.repeat));
    }
    next() { if (!this.queue.length) return; this.loadTrack(this.shuffle ? Math.floor(Math.random() * this.queue.length) : this.index + 1, true); }
    prev() { if (!this.queue.length) return; if (this.audio.currentTime > 4) { this.audio.currentTime = 0; return; } this.loadTrack(this.index - 1, true); }
    syncRange(selector, value, max, percent) {
        const el = this.qs(selector);
        if (!el) return;
        el.max = max || 0;
        if (document.activeElement !== el) el.value = value || 0;
        el.style.setProperty('--progress', `${percent || 0}%`);
    }
    updateProgress() {
        const current = this.audio.currentTime || 0;
        const duration = this.audio.duration || 0;
        const percent = duration ? Math.min(100, (current / duration) * 100) : 0;
        this.syncRange('#progress', current, duration, percent);
        this.syncRange('#miniProgress', current, duration, percent);
        ['#currentTime', '#miniCurrentTime'].forEach(id => { const el = this.qs(id); if (el) el.textContent = this.format(current); });
    }
    updateDuration() {
        const duration = this.audio.duration || 0;
        ['#duration', '#miniDuration'].forEach(id => { const el = this.qs(id); if (el) el.textContent = this.format(duration); });
        this.updateProgress();
    }
    keyboard(e) {
        const active = document.activeElement;
        if (active && ['INPUT','TEXTAREA','SELECT'].includes(active.tagName)) return;
        if (e.code === 'Space') { e.preventDefault(); this.toggle(); }
        if (e.code === 'ArrowRight') this.next();
        if (e.code === 'ArrowLeft') this.prev();
    }
    format(sec) { sec = Number.isFinite(Number(sec)) ? Math.floor(Number(sec)) : 0; return `${Math.floor(sec/60)}:${String(sec%60).padStart(2,'0')}`; }
    esc(str) { return String(str ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c])); }
    escAttr(str) { return this.esc(str).replace(/`/g, '&#096;'); }
}

document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('audioEngine')) window.JazzCOPlayer = new JazzPlayer();
});
