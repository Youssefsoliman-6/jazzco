<?php
// JazzCO configuration for XAMPP/phpMyAdmin.
// Edit only if your local MySQL setup differs from the XAMPP default.

define('APP_NAME', 'JazzCO');
define('DB_HOST', 'localhost');
define('DB_NAME', 'jazzco_db');
define('DB_USER', 'root');
define('DB_PASS', '');

define('BASE_DIR', dirname(__DIR__));
define('UPLOAD_DIR', BASE_DIR . DIRECTORY_SEPARATOR . 'uploads');
define('DEFAULT_COVER', 'assets/images/covers/default-cover.svg');
define('DEFAULT_AVATAR', 'assets/images/avatars/default-avatar.svg');

// Works whether the project is served as /jazzco or another folder inside htdocs.
$scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
$baseParts = explode('/', trim($scriptName, '/'));
$projectFolder = $baseParts[0] ?? 'jazzco';
define('BASE_URL', '/' . $projectFolder . '/');

$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => BASE_URL,
        'domain' => '',
        'secure' => $isHttps,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_name('JAZZCOSESSID');
    session_start();
}

// Harden sessions a bit without breaking XAMPP local development.
if (!isset($_SESSION['created_at'])) {
    $_SESSION['created_at'] = time();
}
if (time() - $_SESSION['created_at'] > 1800) {
    session_regenerate_id(true);
    $_SESSION['created_at'] = time();
}

header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
?>
