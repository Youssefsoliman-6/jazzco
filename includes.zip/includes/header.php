<?php
require_once __DIR__ . '/functions.php';
$user = current_user($pdo);
$settings = $pdo->query("SELECT setting_key, setting_value FROM settings")->fetchAll(PDO::FETCH_KEY_PAIR);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($settings['site_name'] ?? APP_NAME) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <script>
        (function () {
            try {
                var savedTheme = localStorage.getItem('jazzco_theme');
                if (savedTheme === 'light') document.documentElement.setAttribute('data-theme', 'light');
            } catch (e) {}
        })();
    </script>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<div class="loading-screen" id="loadingScreen">
    <div class="loader-vinyl"></div>
    <p>Loading JazzCO...</p>
</div>
<header class="site-header glass">
    <a href="<?= BASE_URL ?>index.php" class="brand"><span class="brand-orb"></span>JazzCO</a>
    <button class="hamburger" id="hamburger" aria-label="Open menu"><span></span><span></span><span></span></button>
    <nav class="main-nav" id="mainNav">
        <a href="<?= BASE_URL ?>index.php">Home</a>
        <a href="<?= BASE_URL ?>library.php">Library</a>
        <a href="<?= BASE_URL ?>albums.php">Albums</a>
        <a href="<?= BASE_URL ?>player.php">Player</a>
        <a href="<?= BASE_URL ?>playlists.php">Playlists</a>
        <?php if ($user): ?>
            <a href="<?= BASE_URL ?>profile.php">Profile</a>
            <a href="<?= BASE_URL ?>logout.php" class="nav-pill">Logout</a>
        <?php else: ?>
            <a href="<?= BASE_URL ?>login.php">Login</a>
            <a href="<?= BASE_URL ?>register.php" class="nav-pill">Register</a>
        <?php endif; ?>
    </nav>
    <button class="theme-toggle" type="button" data-theme-toggle aria-label="Toggle dark and light mode">Light</button>
</header>
<div class="toast-stack" id="toastStack"></div>
<?php foreach (pull_flashes() as $flash): ?>
    <script>window.__JAZZ_FLASHES__ = window.__JAZZ_FLASHES__ || []; window.__JAZZ_FLASHES__.push(<?= json_encode($flash) ?>);</script>
<?php endforeach; ?>
<main class="page-wrap">
