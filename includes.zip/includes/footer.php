</main>
<footer class="site-footer">
    <div>
        <a class="brand footer-brand" href="<?= BASE_URL ?>index.php"><span class="brand-orb"></span>JazzCO</a>
        <p>Premium streaming vibes with independent artist energy.</p>
    </div>
    <div class="footer-links">
        <a href="#">Instagram</a>
        <a href="#">TikTok</a>
        <a href="#">X</a>
        <a href="#">Support</a>
    </div>
</footer>

<div class="mini-player spotify-bar" aria-label="Global music player">
    <div class="mini-track-meta" aria-live="polite">
        <img id="miniCover" src="<?= BASE_URL ?>assets/images/covers/default-cover.svg" alt="mini cover">
        <div>
            <h4 id="miniTitle">Nothing playing</h4>
            <p id="miniArtist">Choose a track</p>
        </div>
    </div>

    <div class="mini-center">
        <div class="mini-controls-row">
            <span id="miniCurrentTime" class="mini-time">0:00</span>
            <button id="miniShuffleBtn" class="mini-icon" title="Shuffle" aria-label="Shuffle">⤨</button>
            <button id="miniPrevBtn" class="mini-icon" title="Previous" aria-label="Previous">⏮</button>
            <button id="miniPlayBtn" class="mini-play-btn" title="Play" aria-label="Play">▶</button>
            <button id="miniNextBtn" class="mini-icon" title="Next" aria-label="Next">⏭</button>
            <button id="miniRepeatBtn" class="mini-icon" title="Repeat" aria-label="Repeat">⟲</button>
            <span id="miniDuration" class="mini-time">0:00</span>
        </div>
        <input id="miniProgress" class="range player-bar-range" type="range" min="0" value="0" step="1" aria-label="Song progress">
    </div>

    <div class="mini-volume">
        <button id="miniQueueBtn" class="mini-icon" title="Open queue" aria-label="Open queue">☰</button>
        <span>🔈</span>
        <input id="miniVolume" class="range player-bar-volume" type="range" min="0" max="1" step="0.01" value="0.75" aria-label="Volume">
    </div>
</div>

<div class="queue-drawer glass" id="queueDrawer" aria-hidden="true">
    <div class="drawer-head">
        <div>
            <h3>Song queue</h3>
            <p class="helper">Your queue is saved in this browser and keeps playing across JazzCO pages.</p>
        </div>
        <button class="icon-btn" id="closeQueueDrawer" type="button" aria-label="Close queue">×</button>
    </div>
    <div id="globalQueueList" class="queue-list compact"></div>
    <div class="drawer-actions">
        <button class="btn small" id="clearQueueBtn" type="button">Clear queue</button>
        <a class="btn small primary" href="<?= BASE_URL ?>player.php">Open full player</a>
    </div>
</div>
<div class="modal-backdrop" id="modalBackdrop" aria-hidden="true"></div>

<div class="playlist-modal glass" id="playlistModal" aria-hidden="true">
    <div class="drawer-head">
        <div>
            <h3>Add to playlist</h3>
            <p class="helper" id="playlistModalSong">Choose a playlist for this song.</p>
        </div>
        <button class="icon-btn" id="closePlaylistModal" type="button" aria-label="Close playlist modal">×</button>
    </div>
    <?php if ($user): ?>
        <div id="playlistChooser" class="playlist-chooser"></div>
        <hr style="border:0;border-top:1px solid var(--border);margin:1rem 0;">
        <form id="quickPlaylistForm" class="form-grid">
            <div class="input-group"><label>Create new playlist</label><input name="name" placeholder="Playlist name" minlength="2" required></div>
            <div class="input-group"><label>Description</label><textarea name="description" placeholder="Optional"></textarea></div>
            <label class="check-line"><input type="checkbox" name="is_public"> Public playlist</label>
            <button class="btn primary" type="submit">Create and add song</button>
        </form>
    <?php else: ?>
        <div class="empty-state">Please <a class="gradient-text" href="<?= BASE_URL ?>login.php">login</a> to create playlists and save songs.</div>
    <?php endif; ?>
</div>

<audio id="audioEngine" preload="metadata"></audio>
<script>
    window.JAZZCO_BASE_URL = <?= json_encode(BASE_URL) ?>;
    window.JAZZCO_LOGGED_IN = <?= $user ? 'true' : 'false' ?>;
</script>
<script src="<?= BASE_URL ?>assets/js/app.js"></script>
<script src="<?= BASE_URL ?>assets/js/player.js"></script>
</body>
</html>
