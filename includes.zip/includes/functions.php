<?php
require_once __DIR__ . '/db.php';

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function asset_url($path) {
    if (!$path) return BASE_URL . DEFAULT_COVER;
    if (preg_match('#^https?://#', $path)) return $path;
    return BASE_URL . ltrim($path, '/');
}

function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], (string)$token);
}

function current_user(PDO $pdo) {
    if (!empty($_SESSION['user_id'])) {
        $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
        $stmt->execute([$_SESSION['user_id']]);
        return $stmt->fetch() ?: null;
    }

    if (!empty($_COOKIE['jazzco_remember'])) {
        $rawToken = $_COOKIE['jazzco_remember'];
        $hash = hash('sha256', $rawToken);
        $stmt = $pdo->prepare('SELECT * FROM users WHERE remember_token_hash = ? LIMIT 1');
        $stmt->execute([$hash]);
        $user = $stmt->fetch();
        if ($user) {
            $_SESSION['user_id'] = (int)$user['id'];
            return $user;
        }
    }

    return null;
}

function require_login(PDO $pdo) {
    $user = current_user($pdo);
    if (!$user) {
        header('Location: ' . BASE_URL . 'login.php');
        exit;
    }
    return $user;
}

function require_admin() {
    if (empty($_SESSION['admin_id'])) {
        header('Location: ' . BASE_URL . 'admin/login.php');
        exit;
    }
}

function admin_user(PDO $pdo) {
    if (empty($_SESSION['admin_id'])) return null;
    $stmt = $pdo->prepare('SELECT * FROM admins WHERE id = ? LIMIT 1');
    $stmt->execute([$_SESSION['admin_id']]);
    return $stmt->fetch() ?: null;
}

function json_response($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function clean_filename($name) {
    $name = preg_replace('/[^A-Za-z0-9_.-]/', '_', $name);
    $name = trim($name, '._');
    return $name !== '' ? $name : 'jazzco_file';
}

function ini_size_to_bytes($value) {
    $value = trim((string)$value);
    if ($value === '') return 0;
    $unit = strtolower(substr($value, -1));
    $number = (float)$value;
    switch ($unit) {
        case 'g': $number *= 1024;
        case 'm': $number *= 1024;
        case 'k': $number *= 1024;
    }
    return (int)$number;
}

function bytes_to_human($bytes) {
    $bytes = (int)$bytes;
    if ($bytes >= 1024 * 1024) return round($bytes / 1024 / 1024, 1) . ' MB';
    if ($bytes >= 1024) return round($bytes / 1024, 1) . ' KB';
    return $bytes . ' bytes';
}

function upload_error_message($code) {
    $uploadMax = ini_get('upload_max_filesize');
    $postMax = ini_get('post_max_size');
    $messages = [
        UPLOAD_ERR_INI_SIZE => "The uploaded file is bigger than your PHP limit. Current upload_max_filesize is {$uploadMax} and post_max_size is {$postMax}.",
        UPLOAD_ERR_FORM_SIZE => 'The uploaded file is bigger than the form limit.',
        UPLOAD_ERR_PARTIAL => 'The file was only partially uploaded. Please try again.',
        UPLOAD_ERR_NO_FILE => 'No file was selected.',
        UPLOAD_ERR_NO_TMP_DIR => 'PHP cannot find its temporary upload folder. Check your XAMPP PHP configuration.',
        UPLOAD_ERR_CANT_WRITE => 'PHP could not write the uploaded file to disk. Check folder permissions.',
        UPLOAD_ERR_EXTENSION => 'A PHP extension stopped the upload.',
    ];
    return $messages[$code] ?? ('Upload failed with PHP error code: ' . $code);
}

function assert_post_size_not_exceeded() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;
    $contentLength = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
    $postMaxBytes = ini_size_to_bytes(ini_get('post_max_size'));
    if ($postMaxBytes > 0 && $contentLength > $postMaxBytes) {
        throw new RuntimeException('Upload is too large for PHP post_max_size. Current post_max_size is ' . ini_get('post_max_size') . '. Increase it in php.ini, restart Apache, then try again.');
    }
}

function ensure_upload_dir(string $subdir) {
    $safeSubdir = trim(str_replace(['..', '\\'], ['', '/'], $subdir), '/');
    $targetDir = UPLOAD_DIR . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $safeSubdir);

    if (!is_dir(UPLOAD_DIR)) {
        @mkdir(UPLOAD_DIR, 0775, true);
    }
    if (!is_dir($targetDir)) {
        @mkdir($targetDir, 0775, true);
    }

    // On macOS/XAMPP, Apache sometimes needs group write permission. Try to fix it automatically first.
    @chmod(UPLOAD_DIR, 0775);
    @chmod($targetDir, 0775);

    if (!is_dir($targetDir)) {
        throw new RuntimeException('Upload folder does not exist and could not be created: ' . $targetDir);
    }
    if (!is_writable($targetDir)) {
        $macHint = ' On macOS XAMPP, run this in Terminal: chmod -R 777 /Applications/XAMPP/xamppfiles/htdocs/jazzco/uploads';
        throw new RuntimeException('Upload folder is not writable: ' . $targetDir . '.' . $macHint);
    }

    return $targetDir;
}

function allowed_file_by_extension(string $filename, array $extensions) {
    if (!$extensions) return true;
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    return in_array($ext, array_map('strtolower', $extensions), true);
}

function upload_file(array $file, string $subdir, array $allowedMimes, int $maxBytes, array $allowedExtensions = []) {
    if (empty($file) || empty($file['name']) || (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE)) {
        return null;
    }

    $error = (int)($file['error'] ?? UPLOAD_ERR_OK);
    if ($error !== UPLOAD_ERR_OK) {
        throw new RuntimeException(upload_error_message($error));
    }

    $tmp = $file['tmp_name'] ?? '';
    if ($tmp === '' || !is_uploaded_file($tmp)) {
        throw new RuntimeException('Invalid upload request. Please choose the file again.');
    }

    $size = (int)($file['size'] ?? 0);
    if ($size <= 0) {
        throw new RuntimeException('The uploaded file is empty.');
    }
    if ($size > $maxBytes) {
        throw new RuntimeException('File is too large. Maximum allowed size is ' . bytes_to_human($maxBytes) . '.');
    }

    $originalName = (string)($file['name'] ?? 'upload');
    if ($allowedExtensions && !allowed_file_by_extension($originalName, $allowedExtensions)) {
        throw new RuntimeException('Invalid file extension. Allowed extensions: ' . implode(', ', $allowedExtensions) . '.');
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($tmp) ?: 'application/octet-stream';

    // Some macOS/browser/XAMPP combinations identify MP3 files as application/octet-stream.
    // If the extension is allowed, accept generic binary MIME only for explicitly allowed extensions.
    $genericMimes = ['application/octet-stream', 'binary/octet-stream'];
    $mimeAllowed = in_array($mime, $allowedMimes, true);
    $genericAllowedByExtension = in_array($mime, $genericMimes, true) && $allowedExtensions && allowed_file_by_extension($originalName, $allowedExtensions);

    if (!$mimeAllowed && !$genericAllowedByExtension) {
        throw new RuntimeException('Invalid file type detected: ' . $mime . '. Please upload a valid file.');
    }

    $extMap = [
        'audio/mpeg' => 'mp3',
        'audio/mp3' => 'mp3',
        'audio/x-mpeg' => 'mp3',
        'audio/x-mp3' => 'mp3',
        'audio/mpeg3' => 'mp3',
        'audio/x-mpeg-3' => 'mp3',
        'image/jpeg' => 'jpg',
        'image/pjpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'image/gif' => 'gif',
    ];

    $ext = $extMap[$mime] ?? strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
    if ($allowedExtensions && !in_array(strtolower($ext), array_map('strtolower', $allowedExtensions), true)) {
        $ext = strtolower($allowedExtensions[0]);
    }

    $targetDir = ensure_upload_dir($subdir);
    $safeBase = clean_filename(pathinfo($originalName, PATHINFO_FILENAME));
    $newName = $safeBase . '_' . date('Ymd_His') . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
    $target = $targetDir . DIRECTORY_SEPARATOR . $newName;

    if (!move_uploaded_file($tmp, $target)) {
        throw new RuntimeException('Could not save uploaded file. Check that the uploads folder is writable by Apache/XAMPP.');
    }

    @chmod($target, 0644);
    return 'uploads/' . trim($subdir, '/') . '/' . $newName;
}

function upload_audio_file(array $file, string $subdir = 'songs', int $maxBytes = 50000000) {
    return upload_file(
        $file,
        $subdir,
        ['audio/mpeg','audio/mp3','audio/x-mpeg','audio/x-mp3','audio/mpeg3','audio/x-mpeg-3','application/octet-stream'],
        $maxBytes,
        ['mp3']
    );
}

function upload_image_file(array $file, string $subdir = 'covers', int $maxBytes = 5000000) {
    return upload_file(
        $file,
        $subdir,
        ['image/jpeg','image/pjpeg','image/png','image/webp','image/gif'],
        $maxBytes,
        ['jpg','jpeg','png','webp','gif']
    );
}

function get_songs(PDO $pdo, int $limit = 20, int $offset = 0, string $q = '') {
    $params = [];
    $where = '';
    if ($q !== '') {
        $where = 'WHERE s.title LIKE ? OR ar.name LIKE ? OR al.title LIKE ? OR g.name LIKE ?';
        $term = '%' . $q . '%';
        $params = [$term, $term, $term, $term];
    }
    $sql = "SELECT s.*, ar.name AS artist_name, al.title AS album_title, g.name AS genre_name
            FROM songs s
            LEFT JOIN artists ar ON ar.id = s.artist_id
            LEFT JOIN albums al ON al.id = s.album_id
            LEFT JOIN genres g ON g.id = s.genre_id
            $where
            ORDER BY s.created_at DESC
            LIMIT $limit OFFSET $offset";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function song_to_api(array $song) {
    return [
        'id' => (int)$song['id'],
        'title' => $song['title'],
        'artist' => $song['artist_name'] ?? 'Unknown Artist',
        'album' => $song['album_title'] ?? 'Single',
        'genre' => $song['genre_name'] ?? 'Unknown',
        'duration' => (int)($song['duration_seconds'] ?? 0),
        'src' => asset_url($song['file_path']),
        'cover' => asset_url($song['cover_path'] ?: DEFAULT_COVER),
        'plays' => (int)($song['plays'] ?? 0),
        'trending' => (int)($song['is_trending'] ?? 0) === 1,
    ];
}

function format_time($seconds) {
    $seconds = max(0, (int)$seconds);
    return floor($seconds / 60) . ':' . str_pad((string)($seconds % 60), 2, '0', STR_PAD_LEFT);
}

function flash($type, $message) {
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function pull_flashes() {
    $items = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $items;
}

function ensure_albums_user_column(PDO $pdo) {
    // Keeps older imported databases compatible with the new user-created albums feature.
    try {
        $stmt = $pdo->query("SHOW COLUMNS FROM albums LIKE 'user_id'");
        if (!$stmt->fetch()) {
            $pdo->exec("ALTER TABLE albums ADD COLUMN user_id INT NULL AFTER id, ADD INDEX idx_albums_user (user_id)");
            try {
                $pdo->exec("ALTER TABLE albums ADD CONSTRAINT fk_albums_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL");
            } catch (Throwable $ignored) {
                // Some MySQL/MariaDB versions can fail on FK creation if the table was customized.
                // The feature still works with the indexed user_id column.
            }
        }
    } catch (Throwable $ignored) {
        // Do not break normal pages if the connected user has limited ALTER permissions.
    }
}

function find_or_create_artist(PDO $pdo, string $artistName, ?string $bio = null) {
    $artistName = trim($artistName);
    if ($artistName === '') return null;

    $stmt = $pdo->prepare('SELECT id FROM artists WHERE LOWER(name)=LOWER(?) LIMIT 1');
    $stmt->execute([$artistName]);
    $existing = $stmt->fetchColumn();
    if ($existing) return (int)$existing;

    $stmt = $pdo->prepare('INSERT INTO artists (name, bio, image_path) VALUES (?, ?, ?)');
    $stmt->execute([$artistName, $bio ?: 'JazzCO community artist.', DEFAULT_AVATAR]);
    return (int)$pdo->lastInsertId();
}
?>
