<?php
require_once __DIR__ . '/includes_admin.php';

$editUser = null;
$error = '';

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['create_user'])) {
            $username = trim($_POST['username'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            if ($username === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 6) {
                throw new RuntimeException('Username, valid email, and password of at least 6 characters are required.');
            }
            $avatar = admin_upload_image('profile_picture', 'profiles', 2) ?: DEFAULT_AVATAR;
            $stmt = $pdo->prepare('INSERT INTO users (username, email, password_hash, profile_picture) VALUES (?, ?, ?, ?)');
            $stmt->execute([$username, $email, password_hash($password, PASSWORD_DEFAULT), $avatar]);
            flash('success', 'User created successfully.');
            admin_redirect('users.php');
        }

        if (isset($_POST['update_user'])) {
            $id = (int)($_POST['user_id'] ?? 0);
            $username = trim($_POST['username'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            if ($id <= 0 || $username === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new RuntimeException('User ID, username, and valid email are required.');
            }
            $stmt = $pdo->prepare('SELECT profile_picture FROM users WHERE id=? LIMIT 1');
            $stmt->execute([$id]);
            $current = $stmt->fetch();
            if (!$current) throw new RuntimeException('User not found.');
            $avatar = admin_upload_image('profile_picture', 'profiles', 2) ?: ($current['profile_picture'] ?: DEFAULT_AVATAR);
            if ($password !== '') {
                if (strlen($password) < 6) throw new RuntimeException('New password must be at least 6 characters.');
                $stmt = $pdo->prepare('UPDATE users SET username=?, email=?, password_hash=?, profile_picture=? WHERE id=?');
                $stmt->execute([$username, $email, password_hash($password, PASSWORD_DEFAULT), $avatar, $id]);
            } else {
                $stmt = $pdo->prepare('UPDATE users SET username=?, email=?, profile_picture=? WHERE id=?');
                $stmt->execute([$username, $email, $avatar, $id]);
            }
            flash('success', 'User updated successfully.');
            admin_redirect('users.php');
        }

        if (isset($_POST['delete_user'])) {
            $pdo->prepare('DELETE FROM users WHERE id=?')->execute([(int)$_POST['user_id']]);
            flash('success', 'User deleted.');
            admin_redirect('users.php');
        }
    }

    if (isset($_GET['edit'])) {
        $stmt = $pdo->prepare('SELECT * FROM users WHERE id=? LIMIT 1');
        $stmt->execute([(int)$_GET['edit']]);
        $editUser = $stmt->fetch() ?: null;
    }
} catch (Throwable $e) {
    $error = $e->getMessage();
}

admin_header('Users CRUD');
$users = $pdo->query('SELECT u.*, (SELECT COUNT(*) FROM playlists p WHERE p.user_id=u.id) playlist_count, (SELECT COUNT(*) FROM favorites f WHERE f.user_id=u.id) fav_count FROM users u ORDER BY u.created_at DESC')->fetchAll();
?>
<div class="section-head"><div><h1>Users CRUD</h1><p>Create, read, update, and delete user accounts.</p></div><?php if ($editUser): ?><a class="btn" href="users.php">Cancel edit</a><?php endif; ?></div>
<?php if($error): ?><div class="error-box"><?= e($error) ?></div><?php endif; ?>

<form class="card" method="post" enctype="multipart/form-data">
    <h2><?= $editUser ? 'Edit user' : 'Create user' ?></h2>
    <div class="form-grid admin-form-grid">
        <?php if($editUser): ?><input type="hidden" name="user_id" value="<?= (int)$editUser['id'] ?>"><?php endif; ?>
        <div class="input-group"><label>Username</label><input name="username" value="<?= e($editUser['username'] ?? '') ?>" required></div>
        <div class="input-group"><label>Email</label><input type="email" name="email" value="<?= e($editUser['email'] ?? '') ?>" required></div>
        <div class="input-group"><label><?= $editUser ? 'New password (optional)' : 'Password' ?></label><input type="password" name="password" <?= $editUser ? '' : 'required' ?> minlength="6"></div>
        <div class="input-group"><label>Profile picture</label><input type="file" name="profile_picture" accept="image/*"></div>
        <?php if($editUser): ?><img class="admin-thumb large" src="<?= e(asset_url($editUser['profile_picture'] ?: DEFAULT_AVATAR)) ?>" alt="profile picture"><?php endif; ?>
        <button class="btn primary" name="<?= $editUser ? 'update_user' : 'create_user' ?>"><?= $editUser ? 'Save user changes' : 'Add user' ?></button>
    </div>
</form>

<section class="section card"><h2>All users</h2><div class="table-wrap"><table><thead><tr><th>Photo</th><th>ID</th><th>Username</th><th>Email</th><th>Playlists</th><th>Favorites</th><th>Joined</th><th>Actions</th></tr></thead><tbody>
<?php foreach($users as $u): ?>
<tr><td><img class="admin-thumb" src="<?= e(asset_url($u['profile_picture'] ?: DEFAULT_AVATAR)) ?>" alt="user"></td><td><?= (int)$u['id'] ?></td><td><?= e($u['username']) ?></td><td><?= e($u['email']) ?></td><td><?= (int)$u['playlist_count'] ?></td><td><?= (int)$u['fav_count'] ?></td><td><?= e($u['created_at']) ?></td><td class="table-actions"><a class="btn small" href="users.php?edit=<?= (int)$u['id'] ?>">Edit</a><form method="post" onsubmit="return confirm('Delete this user and all playlists/favorites?')"><input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>"><button class="btn small danger" name="delete_user">Delete</button></form></td></tr>
<?php endforeach; ?>
</tbody></table></div></section>
<?php admin_footer(); ?>
